// PhishGuard — Settings Page

const BUILT_IN_DOMAINS = [
    "google.com", "youtube.com", "gmail.com", "google.co.uk", "google.com.au", "google.ca", "google.de", "google.fr",
    "microsoft.com", "cloud.microsoft", "office.com", "office365.com", "microsoftonline.com",
    "live.com", "outlook.com", "azure.com", "sharepoint.com", "bing.com",
    "apple.com", "icloud.com",
    "amazon.com", "amazon.co.uk", "amazon.com.au", "amazon.de", "amazon.fr", "amazon.co.jp",
    "facebook.com", "instagram.com", "whatsapp.com", "messenger.com",
    "github.com", "paypal.com", "twitter.com", "x.com", "linkedin.com",
    "wikipedia.org", "reddit.com", "netflix.com", "spotify.com",
    "cloudflare.com", "stackoverflow.com", "dropbox.com", "notion.so", "slack.com",
    "zoom.us", "adobe.com",
  ];
  
  const ALL_RULES = [
    { id: "http_instead_of_https",       name: "HTTP instead of HTTPS",          desc: "Flags pages served over insecure HTTP.",                             weight: 1.5,  group: "URL" },
    { id: "ip_in_url",                   name: "IP address in URL",               desc: "Flags URLs using a raw IP address instead of a domain name.",        weight: 4.0,  group: "URL" },
    { id: "suspicious_keyword",          name: "Suspicious keywords",             desc: "Flags URLs containing words like login, verify, secure, bank.",       weight: 0.4,  group: "URL" },
    { id: "many_subdomains",             name: "Excessive subdomains",            desc: "Flags URLs with more than 3 dots, suggesting subdomain abuse.",       weight: 0.8,  group: "URL" },
    { id: "long_url",                    name: "Long URL",                        desc: "Flags URLs over 75 characters. Weak signal, may cause false positives.", weight: 0.5, group: "URL" },
    { id: "brand_url_impersonation",     name: "Brand URL impersonation",         desc: "Flags URLs containing brand names outside their real domains.",       weight: 3.5,  group: "URL" },
    { id: "urgent_language",             name: "Urgent language",                 desc: "Flags pages with phrases like 'account suspended' or 'verify now'.",  weight: 2.0,  group: "Content" },
    { id: "password_with_other_signals", name: "Password field + other signals",  desc: "Flags password fields only when combined with other risk signals.",   weight: 1.0,  group: "Content" },
    { id: "form_cross_domain",           name: "Cross-domain form submission",    desc: "Flags forms that send data to a different domain.",                   weight: 4.0,  group: "Forms" },
    { id: "form_no_action",              name: "Form with no action",             desc: "Flags forms that have no submit URL defined.",                        weight: 1.0,  group: "Forms" },
    { id: "many_iframes",                name: "Many iframes",                    desc: "Flags pages with 3 or more iframes.",                                 weight: 0.8,  group: "DOM" },
    { id: "many_hidden_elements",        name: "Many hidden elements",            desc: "Flags pages with 10 or more hidden elements.",                        weight: 0.8,  group: "DOM" },
    { id: "brand_content_mismatch",      name: "Brand content mismatch",          desc: "Flags pages that mention a brand but whose domain doesn't match.",    weight: 3.5,  group: "DOM" },
    { id: "mixed_content",               name: "Mixed content (SSL)",             desc: "Flags HTTPS pages that load scripts or iframes over HTTP.",           weight: 2.0,  group: "SSL" },
  ];
  
  // ── Helpers ────────────────────────────────────────────────────────────────
  
  function showSaveStatus(msg = "Saved") {
    const el = document.getElementById("saveStatus");
    if (!el) return;
    el.textContent = "✓ " + msg;
    el.classList.add("visible");
    setTimeout(() => el.classList.remove("visible"), 2000);
  }
  
  // ── API Key section ────────────────────────────────────────────────────────
  
  function initApiKey() {
    const display = document.getElementById("vtKeyDisplay");
    const toggle  = document.getElementById("vtKeyToggle");
    const remove  = document.getElementById("vtKeyRemove");
  
    chrome.storage.local.get(["vtApiKey"], (data) => {
      if (data.vtApiKey) {
        display.value = data.vtApiKey;
        display.type  = "password";
      }
    });
  
    toggle?.addEventListener("click", () => {
      const isPassword = display.type === "password";
      display.type   = isPassword ? "text" : "password";
      toggle.textContent = isPassword ? "Hide" : "Show";
    });
  
    // Save on blur if changed
    display?.addEventListener("blur", () => {
      const key = display.value.trim();
      if (!key) return;
      chrome.storage.local.set({ vtApiKey: key }, () => showSaveStatus("API key saved"));
    });
  
    remove?.addEventListener("click", () => {
      chrome.storage.local.remove(["vtApiKey"], () => {
        display.value = "";
        showSaveStatus("API key removed");
      });
    });
  }
  
  // ── Trusted Domains section ────────────────────────────────────────────────
  
  function renderDomains(customDomains) {
    const list = document.getElementById("domainList");
    if (!list) return;
  
    const builtIn = BUILT_IN_DOMAINS.map(d =>
      `<div class="domain-item builtin">` +
        `<span>${d}</span>` +
        `<span class="domain-builtin-tag">built-in</span>` +
      `</div>`
    ).join("");
  
    const custom = customDomains.map(d =>
      `<div class="domain-item custom" data-domain="${d}">` +
        `<span>${d}</span>` +
        `<button class="domain-remove" data-domain="${d}" title="Remove">×</button>` +
      `</div>`
    ).join("");
  
    list.innerHTML = custom + builtIn;
  
    list.querySelectorAll(".domain-remove").forEach(btn => {
      btn.addEventListener("click", () => {
        const domain = btn.dataset.domain;
        chrome.storage.local.get(["customTrustedDomains"], (data) => {
          const updated = (data.customTrustedDomains || []).filter(d => d !== domain);
          chrome.storage.local.set({ customTrustedDomains: updated }, () => {
            renderDomains(updated);
            showSaveStatus("Domain removed");
          });
        });
      });
    });
  }
  
  function initDomains() {
    chrome.storage.local.get(["customTrustedDomains"], (data) => {
      renderDomains(data.customTrustedDomains || []);
    });
  
    document.getElementById("domainAddBtn")?.addEventListener("click", () => {
      const input = document.getElementById("domainInput");
      let domain  = input?.value.trim().toLowerCase().replace(/^https?:\/\//, "").replace(/\/.*$/, "");
      if (!domain) return;
  
      chrome.storage.local.get(["customTrustedDomains"], (data) => {
        const existing = data.customTrustedDomains || [];
        if (existing.includes(domain) || BUILT_IN_DOMAINS.includes(domain)) {
          input.value = "";
          return;
        }
        const updated = [domain, ...existing];
        chrome.storage.local.set({ customTrustedDomains: updated }, () => {
          input.value = "";
          renderDomains(updated);
          showSaveStatus("Domain added");
        });
      });
    });
  
    document.getElementById("domainInput")?.addEventListener("keydown", (e) => {
      if (e.key === "Enter") document.getElementById("domainAddBtn")?.click();
    });
  }
  
  // ── Detection Rules section ────────────────────────────────────────────────
  
  function initRules() {
    const ruleList = document.getElementById("ruleList");
    if (!ruleList) return;
  
    chrome.storage.local.get(["disabledRules"], (data) => {
      const disabled = new Set(data.disabledRules || []);
  
      ruleList.innerHTML = ALL_RULES.map(rule => {
        const enabled   = !disabled.has(rule.id);
        const checkId   = `rule-${rule.id}`;
        return (
          `<div class="rule-item">` +
            `<div class="rule-info">` +
              `<div class="rule-name">${rule.name}</div>` +
              `<div class="rule-desc">${rule.desc}</div>` +
              `<div class="rule-weight">weight: ${rule.weight} · group: ${rule.group}</div>` +
            `</div>` +
            `<label class="toggle" title="${enabled ? "Disable" : "Enable"} this rule">` +
              `<input type="checkbox" id="${checkId}" data-rule="${rule.id}" ${enabled ? "checked" : ""}>` +
              `<div class="toggle-track"></div>` +
              `<div class="toggle-thumb"></div>` +
            `</label>` +
          `</div>`
        );
      }).join("");
  
      ruleList.querySelectorAll("input[type='checkbox']").forEach(input => {
        input.addEventListener("change", () => {
          chrome.storage.local.get(["disabledRules"], (data) => {
            const disabledSet = new Set(data.disabledRules || []);
            if (input.checked) {
              disabledSet.delete(input.dataset.rule);
            } else {
              disabledSet.add(input.dataset.rule);
            }
            chrome.storage.local.set({ disabledRules: [...disabledSet] }, () => {
              showSaveStatus(input.checked ? "Rule enabled" : "Rule disabled");
            });
          });
        });
      });
    });
  }
  
  // ── Init ───────────────────────────────────────────────────────────────────
  
  document.addEventListener("DOMContentLoaded", () => {
    initApiKey();
    initDomains();
    initRules();
  });