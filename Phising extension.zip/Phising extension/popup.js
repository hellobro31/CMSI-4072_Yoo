document.addEventListener("DOMContentLoaded", () => {
  const testBtn    = document.getElementById("testBtn");
  const urlInput   = document.getElementById("urlInput");
  const resultText = document.getElementById("resultText");

  if (!testBtn || !urlInput || !resultText) {
    console.error("Missing popup elements");
    return;
  }

  // ── Helpers ────────────────────────────────────────────────────────────────

  function escapeHtml(text) {
    return String(text)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;");
  }

  /**
   * Returns true if `url` contains `brand` but NOT as a legitimate domain.
   * Handles ccTLDs like google.co.uk, paypal.com.au, amazon.co.jp correctly.
   */
  function isBrandImpersonation(url, brand) {
    if (!url.includes(brand)) return false;
    const legitimateDomain = new RegExp(
      brand + "\\.(com|co\\.|net|org|io|gov|edu)" +
      "|\\." + brand + "(/|$|\\?)",
      "i"
    );
    return !legitimateDomain.test(url);
  }

  // ── Weights & thresholds (mirrors content.js) ─────────────────────────────

  const WEIGHTS = {
    http_instead_of_https:   1.5,
    ip_in_url:               4.0,
    suspicious_keyword:      0.4,
    many_subdomains:         0.8,
    long_url:                0.5,
    brand_url_impersonation: 3.5,
  };

  const KEYWORD_CAP         = 1.5;
  const THRESHOLD_DANGEROUS  = 5.0;
  const THRESHOLD_SUSPICIOUS = 3.0;

  // ── URL analysis (for manually pasted URLs) ────────────────────────────────

  function analyzeUrl(url) {
    let score = 0;
    const reasons = [];
    const lowerUrl = url.toLowerCase();

    if (lowerUrl.startsWith("http://")) {
      score += WEIGHTS.http_instead_of_https;
      reasons.push("Uses HTTP instead of HTTPS");
    }

    if (/https?:\/\/(\d{1,3}\.){3}\d{1,3}/.test(lowerUrl)) {
      score += WEIGHTS.ip_in_url;
      reasons.push("Uses an IP address instead of a normal domain");
    }

    const suspiciousWords = ["login", "verify", "secure", "update", "bank", "account"];
    let keywordScore = 0;
    for (const word of suspiciousWords) {
      if (lowerUrl.includes(word)) {
        keywordScore += WEIGHTS.suspicious_keyword;
        reasons.push(`Contains suspicious keyword: "${word}"`);
      }
    }
    score += Math.min(keywordScore, KEYWORD_CAP);

    const dotCount = (url.match(/\./g) || []).length;
    if (dotCount > 3) {
      score += WEIGHTS.many_subdomains;
      reasons.push("Contains many dots or subdomains");
    }

    if (url.length > 75) {
      score += WEIGHTS.long_url;
      reasons.push("URL is unusually long");
    }

    const fakeBrands = ["google", "paypal", "amazon", "apple", "microsoft", "bank"];
    for (const brand of fakeBrands) {
      if (isBrandImpersonation(lowerUrl, brand)) {
        score += WEIGHTS.brand_url_impersonation;
        reasons.push(`Possible impersonation of "${brand}"`);
      }
    }

    if (reasons.length === 0) {
      reasons.push("No obvious URL-based phishing indicators found");
    }

    const roundedScore = Math.round(score * 10) / 10;
    return { score: roundedScore, reasons };
  }

  // Domains that are always considered safe
  const TRUSTED_DOMAINS = [
    // Google
    "google.com", "youtube.com", "gmail.com", "google.co.uk",
    "google.com.au", "google.ca", "google.de", "google.fr",
    // Microsoft
    "microsoft.com", "cloud.microsoft", "office.com", "office365.com",
    "microsoftonline.com", "live.com", "outlook.com", "azure.com",
    "sharepoint.com", "teams.microsoft.com", "bing.com",
    // Apple
    "apple.com", "icloud.com",
    // Amazon
    "amazon.com", "amazon.co.uk", "amazon.com.au", "amazon.de",
    "amazon.fr", "amazon.co.jp", "aws.amazon.com",
    // Meta
    "facebook.com", "instagram.com", "whatsapp.com", "messenger.com",
    // Others
    "github.com", "paypal.com",
    "twitter.com", "x.com", "linkedin.com",
    "wikipedia.org", "reddit.com",
    "netflix.com", "spotify.com",
    "cloudflare.com", "stackoverflow.com",
    "dropbox.com", "notion.so", "slack.com",
    "zoom.us", "adobe.com",
  ];

  function isTrustedDomain(hostname) {
    return TRUSTED_DOMAINS.some(trusted => hostname === trusted || hostname.endsWith("." + trusted));
  }

  function getLabel(score) {
    if (score >= THRESHOLD_DANGEROUS)  return "Dangerous";
    if (score >= THRESHOLD_SUSPICIOUS) return "Suspicious";
    return "Safe";
  }

  // ── Icons (colorblind-safe) ────────────────────────────────────────────────

  const STATUS_ICONS = {
    safe: `<svg class="status-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="9 12 11 14 15 10"/></svg>`,
    suspicious: `<svg class="status-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`,
    dangerous: `<svg class="status-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>`,
  };

  // ── Score bar ──────────────────────────────────────────────────────────────

  // Max visual scale — scores above this pin the bar to full
  const BAR_MAX = 8.0;

  function buildScoreBar(score, labelClass) {
    const pct = Math.min((score / BAR_MAX) * 100, 100).toFixed(1);
    const suspPct  = ((THRESHOLD_SUSPICIOUS / BAR_MAX) * 100).toFixed(1);
    const dangPct  = ((THRESHOLD_DANGEROUS  / BAR_MAX) * 100).toFixed(1);

    return (
      `<div class="score-bar-wrap">` +
        `<div class="score-bar-labels">` +
          `<span>0</span>` +
          `<span>score: ${score}</span>` +
          `<span>${BAR_MAX}+</span>` +
        `</div>` +
        `<div class="score-bar-track">` +
          `<div class="score-bar-fill ${labelClass}" style="width:${pct}%"></div>` +
        `</div>` +
        `<div class="score-bar-markers">` +
          `<span class="score-bar-marker" style="left:${suspPct}%">⚑ ${THRESHOLD_SUSPICIOUS}</span>` +
          `<span class="score-bar-marker" style="left:${dangPct}%">⚑ ${THRESHOLD_DANGEROUS}</span>` +
        `</div>` +
      `</div>`
    );
  }

  // ── Render ─────────────────────────────────────────────────────────────────

  function renderResult(url, totalScore, label, source, reasons, timestamp = "", isRealtime = false) {
    const labelClass = label.toLowerCase();

    // Update the header status dot
    const dot = document.getElementById("statusDot");
    if (dot) dot.className = "header-dot " + labelClass;

    const metaLines = [
      `<div><strong>Source:</strong> ${escapeHtml(source)}</div>`,
      timestamp ? `<div><strong>Scanned:</strong> ${escapeHtml(timestamp)}</div>` : "",
    ].filter(Boolean).join("");

    const reasonItems = reasons.map(r => `<li>${escapeHtml(r)}</li>`).join("");

    // Report button — only shown for real-time scans, not manual URL tests
    const reportRow = isRealtime
      ? `<div class="report-row">` +
          `<span class="reported-badge" id="reportedBadge">` +
            `<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 12 11 14 15 10"/><circle cx="12" cy="12" r="10"/></svg>` +
            ` Reported` +
          `</span>` +
          `<button class="report-btn" id="reportBtn">` +
            `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/></svg>` +
            ` Report as phishing` +
          `</button>` +
        `</div>`
      : "";

    resultText.innerHTML =
      `<div class="result-box ${labelClass}">` +
        `<div class="result-label ${labelClass}">${STATUS_ICONS[labelClass] || ""} ${escapeHtml(label)}</div>` +
        buildScoreBar(totalScore, labelClass) +
        `<div class="result-meta">${metaLines}</div>` +
        `<div class="result-url"><strong>URL</strong>${escapeHtml(url)}</div>` +
        `<ul class="reasons-list">${reasonItems}</ul>` +
        reportRow +
      `</div>`;

    // Wire up report button after innerHTML is set
    if (isRealtime) {
      checkIfReported(url);
      document.getElementById("reportBtn")?.addEventListener("click", () => reportUrl(url));
    }
  }

  // ── Report functionality ───────────────────────────────────────────────────

  function reportUrl(url) {
    chrome.storage.local.get(["reportedUrls"], (data) => {
      if (chrome.runtime.lastError) return;
      const reported = data.reportedUrls || [];
      if (!reported.includes(url)) reported.push(url);
      chrome.storage.local.set({ reportedUrls: reported }, () => {
        const btn   = document.getElementById("reportBtn");
        const badge = document.getElementById("reportedBadge");
        if (btn)   { btn.classList.add("reported"); btn.textContent = "Reported"; btn.disabled = true; }
        if (badge) { badge.classList.add("visible"); }
      });
    });
  }

  function checkIfReported(url) {
    chrome.storage.local.get(["reportedUrls"], (data) => {
      if (chrome.runtime.lastError) return;
      const reported = data.reportedUrls || [];
      if (reported.includes(url)) {
        const btn   = document.getElementById("reportBtn");
        const badge = document.getElementById("reportedBadge");
        if (btn)   { btn.classList.add("reported"); btn.textContent = "Reported"; btn.disabled = true; }
        if (badge) { badge.classList.add("visible"); }
      }
    });
  }

  // ── Real-time scan result from storage ────────────────────────────────────

  function showStoredRealtimeResult() {
    if (!chrome.storage || !chrome.storage.local) {
      resultText.textContent =
        "Storage is not available. Reload the extension after updating manifest permissions.";
      return;
    }

    chrome.storage.local.get(["latestScanResult"], (data) => {
      if (chrome.runtime.lastError) {
        console.error("Storage read error:", chrome.runtime.lastError.message);
        resultText.textContent = "Could not read stored scan result.";
        return;
      }

      const result = data.latestScanResult;

      if (!result) {
        resultText.textContent = "No real-time scan stored yet. Open a website first.";
        return;
      }

      renderResult(
        result.url,
        result.score,
        result.label,
        "Automatic Real-Time Scan",
        result.reasons,
        result.timestamp || "",
        true  // isRealtime
      );
    });
  }

  // ── Button: test pasted URL ────────────────────────────────────────────────

  testBtn.addEventListener("click", async () => {
    const raw = urlInput.value.trim();

    if (!raw) {
      resultText.textContent = "Please paste a URL first.";
      return;
    }

    let url;
    try {
      url = new URL(raw.startsWith("http") ? raw : "https://" + raw);
    } catch {
      resultText.textContent = "That doesn't look like a valid URL. Make sure it starts with http:// or https://.";
      return;
    }

    // Follow redirect if this is a known URL shortener
    const finalUrl = await checkRedirectChain(url.href);
    showRedirectChain(url.href, finalUrl);

    let resolvedUrl;
    try { resolvedUrl = new URL(finalUrl); } catch { resolvedUrl = url; }

    const analysis = analyzeUrl(resolvedUrl.href);
    let label   = getLabel(analysis.score);
    let reasons = analysis.reasons;

    if (isTrustedDomain(resolvedUrl.hostname.toLowerCase())) {
      label   = "Safe";
      reasons = ["Domain is on the trusted list"];
      analysis.score = 0;
    }

    renderResult(resolvedUrl.href, analysis.score, label, "Pasted URL", reasons);
  });

  // ── History ────────────────────────────────────────────────────────────────

  function renderHistory(history) {
    const section  = document.getElementById("historySection");
    const listEl   = document.getElementById("historyList");

    if (!history || history.length === 0) {
      section.style.display = "none";
      return;
    }

    section.style.display = "block";
    listEl.innerHTML = history.map(entry => {
      const labelClass = entry.label.toLowerCase();
      const host = (() => {
        try { return new URL(entry.url).hostname; } catch { return entry.url; }
      })();
      return (
        `<div class="history-item">` +
          `<div class="h-dot ${labelClass}"></div>` +
          `<div class="h-url" title="${escapeHtml(entry.url)}">${escapeHtml(host)}</div>` +
          `<div class="h-meta">` +
            `<span class="h-label ${labelClass}">${escapeHtml(entry.label)}</span>` +
            `<span class="h-time">${escapeHtml(entry.timestamp)}</span>` +
          `</div>` +
        `</div>`
      );
    }).join("");
  }

  function loadHistory() {
    chrome.storage.local.get(["scanHistory"], (data) => {
      if (chrome.runtime.lastError) return;
      renderHistory(data.scanHistory || []);
    });
  }

  document.getElementById("clearBtn")?.addEventListener("click", () => {
    chrome.storage.local.remove(["scanHistory"], () => {
      renderHistory([]);
    });
  });

  // ── VirusTotal ─────────────────────────────────────────────────────────────

  function renderVtResult(data) {
    const el = document.getElementById("vtResult");
    if (!el) return;

    if (data.status === "not_found") {
      el.className = "";
      el.innerHTML = `<div class="vt-notice">No previous analysis found for this URL.</div>`;
      return;
    }

    if (data.status === "invalid_key") {
      el.className = "";
      el.innerHTML = `<div class="vt-notice vt-error">Invalid API key — check your key and try again.</div>`;
      return;
    }

    if (data.status === "rate_limited") {
      el.className = "";
      el.innerHTML = `<div class="vt-notice">Rate limit reached — try again in a minute.</div>`;
      return;
    }

    if (data.status === "no_data") {
      el.className = "";
      el.innerHTML = `<div class="vt-notice">No analysis data available yet.</div>`;
      return;
    }

    const clean = (data.harmless || 0) + (data.undetected || 0);

    el.className = "";
    el.innerHTML =
      `<div class="vt-engines">` +
        `<div class="vt-stat malicious">` +
          `<span class="vt-stat-num">${data.malicious}</span>` +
          `<span class="vt-stat-label">Malicious</span>` +
        `</div>` +
        `<div class="vt-stat suspicious">` +
          `<span class="vt-stat-num">${data.suspicious}</span>` +
          `<span class="vt-stat-label">Suspicious</span>` +
        `</div>` +
        `<div class="vt-stat clean">` +
          `<span class="vt-stat-num">${clean}</span>` +
          `<span class="vt-stat-label">Clean</span>` +
        `</div>` +
      `</div>` +
      `<div class="vt-meta">` +
        `<span>${data.total} engines</span>` +
        (data.fromCache ? `<span>cached</span>` : "") +
        (data.analyzedAt ? `<span>last scan ${escapeHtml(data.analyzedAt)}</span>` : "") +
      `</div>`;
  }

  function runVtScan(url) {
    chrome.storage.local.get(["vtApiKey"], (data) => {
      if (chrome.runtime.lastError) return;

      const apiKey = data.vtApiKey;
      const vtSection    = document.getElementById("vtSection");
      const vtKeySection = document.getElementById("vtKeySection");

      if (!apiKey) {
        // No key stored — show the key input section
        if (vtKeySection) vtKeySection.style.display = "block";
        return;
      }

      // Key exists — show results section and query
      if (vtSection) vtSection.style.display = "block";

      chrome.runtime.sendMessage(
        { action: "vtScan", url, apiKey },
        (response) => {
          if (chrome.runtime.lastError || !response) {
            document.getElementById("vtResult").innerHTML =
              `<div class="vt-notice vt-error">Could not reach VirusTotal.</div>`;
            return;
          }
          if (!response.success) {
            document.getElementById("vtResult").innerHTML =
              `<div class="vt-notice vt-error">${escapeHtml(response.error || "Unknown error")}</div>`;
            return;
          }
          renderVtResult(response.data);
        }
      );
    });
  }

  // VirusTotal signup link
  document.getElementById("vtLink")?.addEventListener("click", () => {
    chrome.tabs.create({ url: "https://www.virustotal.com/gui/join-us" });
  });

  // API key save button
  document.getElementById("vtKeySaveBtn")?.addEventListener("click", () => {
    const input  = document.getElementById("vtKeyInput");
    const key    = input?.value.trim();
    if (!key) return;

    chrome.storage.local.set({ vtApiKey: key }, () => {
      const vtKeySection = document.getElementById("vtKeySection");
      const vtSection    = document.getElementById("vtSection");
      if (vtKeySection) vtKeySection.style.display = "none";
      if (vtSection)    vtSection.style.display    = "block";

      // Trigger scan now that we have a key
      chrome.storage.local.get(["latestScanResult"], (data) => {
        if (data.latestScanResult) runVtScan(data.latestScanResult.url);
      });
    });
  });

  // ── Redirect chain detection ───────────────────────────────────────────────

  const URL_SHORTENERS = new Set([
    "bit.ly","t.co","tinyurl.com","goo.gl","ow.ly","buff.ly",
    "short.link","rebrand.ly","tiny.cc","is.gd","cutt.ly","rb.gy",
    "shorturl.at","bl.ink","snip.ly","clck.ru","zpr.io",
  ]);

  function isShortener(hostname) {
    return URL_SHORTENERS.has(hostname.replace(/^www\./, ""));
  }

  function showRedirectChain(originalUrl, finalUrl) {
    const el = document.getElementById("redirectChain");
    if (!el) return;
    if (!finalUrl || finalUrl === originalUrl) { el.style.display = "none"; return; }

    el.style.display = "flex";
    el.innerHTML =
      `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 3 21 3 21 8"/><line x1="4" y1="20" x2="21" y2="3"/><polyline points="21 16 21 21 16 21"/><line x1="15" y1="15" x2="21" y2="21"/></svg>` +
      `<div class="redirect-chain-text">` +
        `<strong>Redirects to</strong>` +
        `<span class="redirect-chain-url">${escapeHtml(finalUrl)}</span>` +
      `</div>`;
  }

  async function checkRedirectChain(url) {
    let hostname;
    try { hostname = new URL(url).hostname; } catch { return url; }
    if (!isShortener(hostname)) return url;

    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ action: "followRedirect", url }, (response) => {
        if (chrome.runtime.lastError || !response?.success) { resolve(url); return; }
        resolve(response.finalUrl || url);
      });
    });
  }

  // ── Rescan button ──────────────────────────────────────────────────────────

  document.getElementById("rescanBtn")?.addEventListener("click", () => {
    const btn = document.getElementById("rescanBtn");
    if (btn) btn.classList.add("spinning");

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs[0]) { if (btn) btn.classList.remove("spinning"); return; }

      chrome.tabs.sendMessage(tabs[0].id, { action: "rescanPage" }, (result) => {
        if (btn) btn.classList.remove("spinning");
        if (chrome.runtime.lastError || !result) {
          resultText.textContent = "Could not rescan — try reloading the page first.";
          return;
        }
        renderResult(result.url, result.score, result.label, "Manual Rescan", result.reasons, result.timestamp, true);
        runVtScan(result.url);
        loadHistory();
      });
    });
  });

  // ── Settings button ────────────────────────────────────────────────────────

  document.getElementById("settingsBtn")?.addEventListener("click", () => {
    chrome.runtime.openOptionsPage();
  });

  // ── Init ───────────────────────────────────────────────────────────────────

  showStoredRealtimeResult();
  loadHistory();

  // Kick off VT scan for the current page
  chrome.storage.local.get(["latestScanResult"], (data) => {
    if (chrome.runtime.lastError || !data.latestScanResult) return;
    runVtScan(data.latestScanResult.url);
  });
});