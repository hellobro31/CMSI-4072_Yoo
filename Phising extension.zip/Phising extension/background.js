// PhishGuard — Background Service Worker
// Handles VirusTotal API lookups and tab security monitoring.

// ── VirusTotal API ─────────────────────────────────────────────────────────

const VT_CACHE_TTL_MS = 60 * 60 * 1000; // 1 hour — respect free tier rate limits

/**
 * Convert a URL to the base64url ID that VirusTotal uses as a resource key.
 * VT expects base64url encoding (no padding, + → -, / → _).
 */
function urlToVtId(url) {
  // btoa works in service workers
  return btoa(url).replace(/=+$/, "").replace(/\+/g, "-").replace(/\//g, "_");
}

async function queryVirusTotal(url, apiKey) {
  const cacheKey = "vt_cache_" + urlToVtId(url).slice(0, 80);

  // Check cache first
  const cached = await new Promise(resolve => {
    chrome.storage.local.get([cacheKey], data => {
      if (chrome.runtime.lastError) { resolve(null); return; }
      resolve(data[cacheKey] || null);
    });
  });

  if (cached && Date.now() - cached.fetchedAt < VT_CACHE_TTL_MS) {
    return { ...cached.result, fromCache: true };
  }

  const vtId   = urlToVtId(url);
  const apiUrl = `https://www.virustotal.com/api/v3/urls/${vtId}`;

  const response = await fetch(apiUrl, {
    headers: { "x-apikey": apiKey }
  });

  if (response.status === 404) {
    return { status: "not_found" };
  }

  if (response.status === 401) {
    return { status: "invalid_key" };
  }

  if (response.status === 429) {
    return { status: "rate_limited" };
  }

  if (!response.ok) {
    throw new Error(`VirusTotal API error: ${response.status}`);
  }

  const json  = await response.json();
  const attrs = json?.data?.attributes;

  if (!attrs) return { status: "no_data" };

  const stats = attrs.last_analysis_stats || {};
  const result = {
    status:      "ok",
    malicious:   stats.malicious   || 0,
    suspicious:  stats.suspicious  || 0,
    harmless:    stats.harmless    || 0,
    undetected:  stats.undetected  || 0,
    total:       Object.values(stats).reduce((a, b) => a + b, 0),
    analyzedAt:  attrs.last_analysis_date
      ? new Date(attrs.last_analysis_date * 1000).toLocaleDateString()
      : null,
  };

  // Cache result
  chrome.storage.local.set({
    [cacheKey]: { result, fetchedAt: Date.now() }
  });

  return result;
}

// ── Tab security monitoring ────────────────────────────────────────────────

/**
 * When a tab finishes loading, check its security state and store it.
 * Chrome exposes a limited amount here — we capture what we can.
 */
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== "complete") return;
  if (!tab.url || !tab.url.startsWith("http")) return;

  const securityInfo = {
    tabId,
    url:       tab.url,
    isHttps:   tab.url.startsWith("https://"),
    // Chrome flags pages with cert errors by not marking them as secure;
    // the best signal available without debugger API is the URL scheme.
    certError: false, // updated below if detectable
  };

  // Store latest security info for this tab
  chrome.storage.local.set({ [`tabSecurity_${tabId}`]: securityInfo });
});

// Clean up security info when tab closes
chrome.tabs.onRemoved.addListener((tabId) => {
  chrome.storage.local.remove([`tabSecurity_${tabId}`]);
});

// ── Message handler ────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

  if (message.action === "followRedirect") {
    (async () => {
      try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 6000);
        const response = await fetch(message.url, {
          redirect: "follow",
          signal: controller.signal,
        });
        clearTimeout(timeout);
        const finalUrl = response.url || message.url;
        sendResponse({ success: true, finalUrl, changed: finalUrl !== message.url });
      } catch (err) {
        sendResponse({ success: false, error: err.message });
      }
    })();
    return true;
  }

  if (message.action === "vtScan") {
    queryVirusTotal(message.url, message.apiKey)
      .then(result => sendResponse({ success: true,  data: result }))
      .catch(err   => sendResponse({ success: false, error: err.message }));
    return true; // keep message channel open for async response
  }

  if (message.action === "getTabSecurity") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs[0]) { sendResponse(null); return; }
      chrome.storage.local.get([`tabSecurity_${tabs[0].id}`], (data) => {
        sendResponse(data[`tabSecurity_${tabs[0].id}`] || null);
      });
    });
    return true;
  }

});