// ── Guard: skip non-web pages (chrome://, about:, file://, etc.) ─────────────
if (window.location.protocol !== "http:" && window.location.protocol !== "https:") {
  // Nothing to scan on internal pages
} else {
  initPhishingDetector();
}

function initPhishingDetector() {

  // ── Session state ──────────────────────────────────────────────────────────

  // URLs dismissed this session — banner won't re-appear for these
  const dismissedUrls = new Set();

  // Rules disabled by user in settings — loaded async at init
  let disabledRules = new Set();
  let customTrustedDomains = [];

  chrome.storage.local.get(["disabledRules", "customTrustedDomains"], (data) => {
    if (chrome.runtime.lastError) return;
    disabledRules        = new Set(data.disabledRules || []);
    customTrustedDomains = data.customTrustedDomains || [];
  });

  // ── Helpers ────────────────────────────────────────────────────────────────

  /**
   * Returns true if `url` contains `brand` but NOT as a legitimate domain.
   * Handles ccTLDs like google.co.uk, paypal.com.au, amazon.co.jp correctly.
   */
  function isBrandImpersonation(url, brand) {
    if (!url.includes(brand)) return false;
    // Allow brand.com / brand.co.uk / brand.net etc.
    // AND brand used as a TLD itself e.g. cloud.microsoft, login.apple
    const legitimateDomain = new RegExp(
      brand + "\\.(com|co\\.|net|org|io|gov|edu)" +
      "|\\." + brand + "(/|$|\\?)",
      "i"
    );
    return !legitimateDomain.test(url);
  }

  // ── Page analysis ──────────────────────────────────────────────────────────

  // Domains that are always considered safe — never scanned
  const TRUSTED_DOMAINS = [
    // Google
    "google.com", "youtube.com", "gmail.com", "google.co.uk",
    "google.com.au", "google.ca", "google.de", "google.fr",
    // Microsoft
    "microsoft.com", "cloud.microsoft", "office.com", "office365.com",
    "microsoftonline.com", "live.com", "outlook.com", "azure.com",
    "sharepoint.com", "teams.microsoft.com", "bing.com",
    // Apple
    "apple.com", "icloud.com",
    // Amazon
    "amazon.com", "amazon.co.uk", "amazon.com.au", "amazon.de",
    "amazon.fr", "amazon.co.jp", "aws.amazon.com",
    // Meta
    "facebook.com", "instagram.com", "whatsapp.com", "messenger.com",
    // Others
    "github.com", "paypal.com",
    "twitter.com", "x.com", "linkedin.com",
    "wikipedia.org", "reddit.com",
    "netflix.com", "spotify.com",
    "cloudflare.com", "stackoverflow.com",
    "dropbox.com", "notion.so", "slack.com",
    "zoom.us", "adobe.com",
  ];

  function isTrustedDomain(hostname) {
    const all = [...TRUSTED_DOMAINS, ...customTrustedDomains];
    return all.some(trusted => hostname === trusted || hostname.endsWith("." + trusted));
  }

  // ── Weights & thresholds ───────────────────────────────────────────────────

  const WEIGHTS = {
    http_instead_of_https:       1.5,
    ip_in_url:                   4.0,
    suspicious_keyword:          0.4,  // per keyword; capped by KEYWORD_CAP
    many_subdomains:             0.8,
    long_url:                    0.5,
    brand_url_impersonation:     3.5,
    urgent_language:             2.0,
    password_with_other_signals: 1.0,
    form_no_action:              1.0,
    form_cross_domain:           4.0,
    form_malformed_action:       1.0,
    many_iframes:                0.8,
    many_hidden_elements:        0.8,
    brand_content_mismatch:      3.5,
    mixed_content:               2.0,  // HTTPS page loading HTTP sub-resources
  };

  const KEYWORD_CAP         = 1.5;
  const THRESHOLD_DANGEROUS  = 5.0;
  const THRESHOLD_SUSPICIOUS = 3.0;

  function analyzeCurrentPage() {
    const reasons = [];
    let score = 0;

    const currentUrl  = window.location.href.toLowerCase();
    const currentHost = window.location.hostname.toLowerCase();

    // Skip scan entirely for trusted domains
    if (isTrustedDomain(currentHost)) {
      return {
        url: window.location.href,
        score: 0,
        label: "Safe",
        reasons: ["Domain is on the trusted list"],
        timestamp: new Date().toLocaleString()
      };
    }
    const pageText    = (document.body?.innerText || "").toLowerCase();
    const title       = (document.title || "").toLowerCase();

    const forms          = Array.from(document.querySelectorAll("form"));
    const passwordFields = document.querySelectorAll("input[type='password']");
    const iframes        = document.querySelectorAll("iframe");
    const hiddenElements = document.querySelectorAll("[hidden], [style*='display:none'], [style*='visibility:hidden']");

    // ── URL signals ──────────────────────────────────────────────────────────

    if (!disabledRules.has("http_instead_of_https") && currentUrl.startsWith("http://")) {
      score += WEIGHTS.http_instead_of_https;
      reasons.push("Uses HTTP instead of HTTPS");
    }

    if (!disabledRules.has("ip_in_url") && /https?:\/\/(\d{1,3}\.){3}\d{1,3}/.test(currentUrl)) {
      score += WEIGHTS.ip_in_url;
      reasons.push("Uses an IP address instead of a normal domain");
    }

    if (!disabledRules.has("suspicious_keyword")) {
      const suspiciousWords = ["login", "verify", "secure", "update", "bank", "account"];
      let keywordScore = 0;
      for (const word of suspiciousWords) {
        if (currentUrl.includes(word)) {
          keywordScore += WEIGHTS.suspicious_keyword;
          reasons.push(`URL contains suspicious keyword: "${word}"`);
        }
      }
      score += Math.min(keywordScore, KEYWORD_CAP);
    }

    if (!disabledRules.has("many_subdomains")) {
      const dotCount = (currentUrl.match(/\./g) || []).length;
      if (dotCount > 3) {
        score += WEIGHTS.many_subdomains;
        reasons.push("URL contains many dots or subdomains");
      }
    }

    if (!disabledRules.has("long_url") && currentUrl.length > 75) {
      score += WEIGHTS.long_url;
      reasons.push("URL is unusually long");
    }

    if (!disabledRules.has("brand_url_impersonation")) {
      const fakeBrands = ["google", "paypal", "amazon", "apple", "microsoft", "bank"];
      for (const brand of fakeBrands) {
        if (isBrandImpersonation(currentUrl, brand)) {
          score += WEIGHTS.brand_url_impersonation;
          reasons.push(`Possible URL impersonation of "${brand}"`);
        }
      }
    }

    // ── Page content signals ─────────────────────────────────────────────────

    if (!disabledRules.has("urgent_language")) {
      const urgentWords = [
        "verify your account",
        "account suspended",
        "confirm your identity",
        "urgent",
        "immediately",
        "login to continue",
        "update your account",
        "security alert"
      ];
      if (urgentWords.some(word => pageText.includes(word))) {
        score += WEIGHTS.urgent_language;
        reasons.push("Page uses urgent or verification-style language");
      }
    }

    if (!disabledRules.has("password_with_other_signals") && passwordFields.length > 0 && score > 0) {
      score += WEIGHTS.password_with_other_signals;
      reasons.push("Page contains a password field alongside other risk indicators");
    }

    // ── Form signals ─────────────────────────────────────────────────────────

    if (!disabledRules.has("form_cross_domain") && !disabledRules.has("form_no_action")) {
      for (const form of forms) {
        const action = form.getAttribute("action") || "";

        if (!action) {
          if (!disabledRules.has("form_no_action")) {
            score += WEIGHTS.form_no_action;
            reasons.push("A form has no action URL");
          }
          continue;
        }

        try {
          const actionUrl = new URL(action, window.location.href);
          if (actionUrl.hostname !== window.location.hostname && !disabledRules.has("form_cross_domain")) {
            score += WEIGHTS.form_cross_domain;
            reasons.push("A form submits to a different domain");
            break;
          }
        } catch {
          score += WEIGHTS.form_malformed_action;
          reasons.push("A form has a malformed action URL");
          break;
        }
      }
    }

    // ── DOM structure signals ────────────────────────────────────────────────

    if (!disabledRules.has("many_iframes") && iframes.length >= 3) {
      score += WEIGHTS.many_iframes;
      reasons.push("Page contains many iframes");
    }

    if (!disabledRules.has("many_hidden_elements") && hiddenElements.length >= 10) {
      score += WEIGHTS.many_hidden_elements;
      reasons.push("Page contains many hidden elements");
    }

    if (!disabledRules.has("brand_content_mismatch")) {
      const brandNames = ["paypal", "google", "microsoft", "apple", "bank of america", "amazon"];
      for (const brand of brandNames) {
        const compactBrand = brand.replace(/\s+/g, "");
        if (
          (pageText.includes(brand) || title.includes(brand)) &&
          !currentHost.includes(compactBrand)
        ) {
          score += WEIGHTS.brand_content_mismatch;
          reasons.push(`Page references "${brand}" but the domain does not appear to match`);
          break;
        }
      }
    }

    // ── SSL / mixed content ──────────────────────────────────────────────────

    if (!disabledRules.has("mixed_content") && window.location.protocol === "https:") {
      const mixedResources = document.querySelectorAll(
        'script[src^="http://"], ' +
        'link[href^="http://"], ' +
        'iframe[src^="http://"], ' +
        'img[src^="http://"], ' +
        'form[action^="http://"]'
      );
      if (mixedResources.length > 0) {
        score += WEIGHTS.mixed_content;
        reasons.push(`Page loads ${mixedResources.length} insecure resource(s) over HTTP (mixed content)`);
      }
    }

    // ── Result ───────────────────────────────────────────────────────────────

    const roundedScore = Math.round(score * 10) / 10;

    let label = "Safe";
    if (score >= THRESHOLD_DANGEROUS)  label = "Dangerous";
    else if (score >= THRESHOLD_SUSPICIOUS) label = "Suspicious";

    if (reasons.length === 0) {
      reasons.push("No obvious page-structure phishing indicators found");
    }

    return {
      url: window.location.href,
      score: roundedScore,
      label,
      reasons,
      timestamp: new Date().toLocaleString()
    };
  }

  // ── Banner ─────────────────────────────────────────────────────────────────

  function removeExistingBanner() {
    const oldBanner = document.getElementById("phishing-detector-banner");
    if (oldBanner) oldBanner.remove();
  }

  function showBanner(result) {
    removeExistingBanner();

    if (result.label === "Safe") return;

    // Don't re-show banner for URLs dismissed this session
    if (dismissedUrls.has(result.url)) return;

    const banner  = document.createElement("div");
    banner.id     = "phishing-detector-banner";
    const bgColor = result.label === "Dangerous" ? "#dc2626" : "#f59e0b";

    Object.assign(banner.style, {
      position:   "fixed",
      top:        "0",
      left:       "0",
      width:      "100%",
      zIndex:     "999999",
      background: bgColor,
      color:      "white",
      padding:    "12px 16px",
      fontFamily: "Arial, sans-serif",
      fontSize:   "14px",
      boxSizing:  "border-box",
      boxShadow:  "0 2px 8px rgba(0,0,0,0.25)"
    });

    // Use textContent / createTextNode throughout to avoid XSS
    const heading = document.createElement("strong");
    heading.textContent = `${result.label} page detected`;

    const scoreSpan = document.createTextNode(` — score ${result.score}`);

    const br = document.createElement("br");

    const topReasons = result.reasons.slice(0, 3).join("; ");
    const reasonText = document.createTextNode(`Top reasons: ${topReasons}`);

    const closeBtn = document.createElement("button");
    closeBtn.textContent = "Dismiss";
    Object.assign(closeBtn.style, {
      marginLeft:   "12px",
      padding:      "6px 10px",
      border:       "none",
      borderRadius: "6px",
      cursor:       "pointer",
      background:   "rgba(255,255,255,0.25)",
      color:        "white",
      fontSize:     "13px"
    });
    closeBtn.addEventListener("click", () => {
      dismissedUrls.add(result.url);
      banner.remove();
    });

    banner.appendChild(heading);
    banner.appendChild(scoreSpan);
    banner.appendChild(br);
    banner.appendChild(reasonText);
    banner.appendChild(closeBtn);

    document.body.appendChild(banner);
  }

  // ── Storage ────────────────────────────────────────────────────────────────

  function saveLatestResult(result) {
    // Build a compact history entry (skip full reasons to save storage space)
    const entry = {
      url:       result.url,
      score:     result.score,
      label:     result.label,
      timestamp: result.timestamp
    };

    chrome.storage.local.get(["scanHistory"], (data) => {
      if (chrome.runtime.lastError) {
        console.error("Phishing Detector: storage read error:", chrome.runtime.lastError.message);
        return;
      }

      let history = data.scanHistory || [];

      // Remove any existing entry for the same URL to avoid duplicates
      history = history.filter(h => h.url !== entry.url);

      // Prepend latest, cap at 20 entries
      history = [entry, ...history].slice(0, 20);

      chrome.storage.local.set({ latestScanResult: result, scanHistory: history }, () => {
        if (chrome.runtime.lastError) {
          console.error("Phishing Detector: storage write error:", chrome.runtime.lastError.message);
          return;
        }
        console.log("Phishing Detector: scan saved:", result);
      });
    });
  }

  // ── Scan ───────────────────────────────────────────────────────────────────

  function runRealtimeScan() {
    // Check reported URLs first — if this page was manually reported, flag it immediately
    chrome.storage.local.get(["reportedUrls"], (data) => {
      if (chrome.runtime.lastError) {
        runAnalysis();
        return;
      }
      const reported = data.reportedUrls || [];
      const currentUrl = window.location.href;
      if (reported.some(r => currentUrl.startsWith(r) || r.startsWith(currentUrl))) {
        const result = {
          url: currentUrl,
          score: 9.0,
          label: "Dangerous",
          reasons: ["This page was manually reported as phishing"],
          timestamp: new Date().toLocaleString()
        };
        saveLatestResult(result);
        showBanner(result);
      } else {
        runAnalysis();
      }
    });
  }

  function runAnalysis() {
    const result = analyzeCurrentPage();
    console.log("Phishing Detector: scan completed:", result);
    saveLatestResult(result);
    showBanner(result);
  }

  // ── Message listener (for popup-triggered scans) ───────────────────────────

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.action === "scanPage" || message.action === "rescanPage") {
      const result = analyzeCurrentPage();
      saveLatestResult(result);
      if (message.action === "rescanPage") showBanner(result);
      sendResponse(result);
      return true;
    }
  });

  // ── Init: single scan after page fully loads ───────────────────────────────
  // One call at window load is sufficient.
  // The 2s fallback handles SPAs that inject content after load.
  if (document.readyState === "complete") {
    runRealtimeScan();
  } else {
    window.addEventListener("load", runRealtimeScan, { once: true });
    // Fallback for SPAs
    setTimeout(() => {
      if (!document.getElementById("phishing-detector-banner")) {
        runRealtimeScan();
      }
    }, 2000);
  }
}